package sample.server;

import java.sql.*;

public class DatabaseController {
    private Connection connection;

    public DatabaseController() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/crypto?serverTimezone=AST", "root", "MyNewPass");
            this.connection = con;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

        public Connection getConnection() {
            return connection;

/*			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from emp");
			while (rs.next())
				System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
			con.close();*/
    }



        public boolean verifyImage(String hash, String username) throws SQLException {

            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT COUNT(*) FROM crypto.imageshash WHERE Username = '"+username+"' and HashCode = '"+hash+"'");

            while(rs.next()) {
                if (rs.getInt(1) != 0)
                    return true;

            }
            return false;
    }
}


