# java-chat-app-using-RSA-encryption
A chat app implemented using server client architecture in java. The messages are fully encrypted using RSA  2048 and digital signiture
